import 'package:flutter/material.dart';

const kContainerColor = Color(0xff1d1d2f);
const kBackgroundColor = Color(0xff161625);
const kIconsize = 30.0;
String bullet = "\u2022 ";



const kTitleTextstyle = TextStyle(
  fontSize: 25.0,
);

